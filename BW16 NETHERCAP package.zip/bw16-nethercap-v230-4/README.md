# BW16 Nethercap firmware NOTRAIL timer/locker

> BW16 / RTL8720DN only. Do NOT flash to ESP8266 / ESP32 boards.
> 仅适用于 BW16 / RTL8720DN，切勿刷入 ESP8266 / ESP32 板子。

![Flashing tutorial / 刷机教程](flashing-tutorial.jpg)

---

## 中文介绍

这是用于 Realtek AmebaD **BW16（RTL8720DN）** 的 NETHERCAP 固件包（应用镜像 `km0_km4_image2-4.bin`，1,425,408 字节）。固件内部路径显示其来源为 **NETHERCAP N ELITE V2.3.0 TRIAL** 版本的 `-4` 变体。

使用网页刷机工具即可完成刷机，无需安装本地刷机软件（需要支持 Web Serial 的 Chrome / Edge 浏览器）：

**刷机网页 / Web Flasher:** https://nethercap-web-flasher-v2.vercel.app

刷好后通过板子热点进入网页控制面板（`8.8.8.8`），无屏幕 / OLED 依赖。

**重要说明（请先读）：**
- 本包内应用固件中仍能检出原作者 Cancro29 的锁定 / 篡改提示字符串，所谓 timer / locker 状态无法仅从文件本身得到证实。此前仅在提供者自己的一块 BW16 上刷入 `-4` 并报告运行正常，这不保证其他板子同样通过。刷机前请自行判断风险。
- 刷机会覆盖原固件和已有设置（包括已改的 WiFi 名称 / 密码，刷后恢复默认）。**务必先备份你板子的原厂固件**，没有备份将无法恢复原厂状态。
- 本固件的原作者为 Cancro29：https://github.com/Cancro29/NETHERCAP

### 文件与刷机地址

| 顺序 | 文件 | 地址 | 大小 | 说明 |
|---|---|---|---|---|
| 1 | `imgtool_flashloader_amebad.bin` | `0x082000` (RAM) | 4,688 B | System Flashloader，必选 / Required |
| 2 | `km0_boot_all.bin` | `0x08000000` | 4,500 B | km0 启动镜像 |
| 3 | `km4_boot_all.bin` | `0x08004000` | 4,456 B | km4 启动镜像 |
| 4 | `km0_km4_image2-4.bin` | `0x08006000` | 1,425,408 B | 应用固件，刷机时在网页里选这个 `-4` 文件（教程图里写作 `km0_km4_image2.bin`，以本包文件名为准） |

SHA-256 见同目录 `SHA256SUMS.txt`，刷前请核对。

### 刷机步骤（对照教程图）

1. 用 Type-C 数据线把 BW16 连到电脑，确认串口（CH340）已被识别。
2. 打开上面的刷机网页，选择波特率 `1500000 (Turbo)`（教程图设置；不稳定时可降速重试）。
3. 在 **1. System Flashloader (RAM)** 处选择 `imgtool_flashloader_amebad.bin`，地址保持 `0x082000`。
4. 在 **2. Firmware Images** 里按上表逐行添加三行，地址和文件一一对应。
5. 让板子进入下载模式（按住 Burn 键、点按 RST、再松开 Burn，具体以你的板子丝印为准）。
6. 点击 **START FLASHING**，等日志显示完成 / Success 100% 再拔线。不要点 ERASE CHIP，除非你明确要整片擦除。
7. 重新上电，连接板子发出的 WiFi 热点，浏览器打开 `8.8.8.8` 进入面板，并第一时间修改默认 WiFi 名称和密码。

### 自愿捐赠（金额随意）

如果这个包对你有帮助，欢迎自愿捐赠，金额随意：

- **EVM (ETH / BNB):** `0x0c230520e1419b1ccd2e54db80d15ae70edada9d`
- **Solana:** `7j2EcTBB7haUZtmKj27JDBLTWJ4tpfwj8fwWvAfyqwZf`

---

## English

This is a NETHERCAP firmware package for the Realtek AmebaD **BW16 (RTL8720DN)**. The application image is `km0_km4_image2-4.bin` (1,425,408 bytes). An internal build path identifies its origin as the **NETHERCAP N ELITE V2.3.0 TRIAL** `-4` variant.

Flashing is done entirely from the web flasher — no local flashing software is required, only a Chrome / Edge browser with Web Serial support:

**Web Flasher:** https://nethercap-web-flasher-v2.vercel.app

After flashing, control is via the board's own hotspot web panel at `8.8.8.8`. No display / OLED is required.

**Please read first:**
- The original author Cancro29's lock / tamper message strings are still present in this binary, and its timer / locker status cannot be proven from the file alone. The `-4` build was previously flashed and reported running normally on one provider-owned BW16 only — that does not guarantee the same result on other boards. Flash at your own judgment and risk.
- Flashing overwrites the existing firmware and settings (including a changed WiFi name / password, which returns to defaults). **Back up your board's original firmware first** — without a backup there is no way back to stock.
- Original author: Cancro29 — https://github.com/Cancro29/NETHERCAP

### Files and flash addresses

| Order | File | Address | Size | Notes |
|---|---|---|---|---|
| 1 | `imgtool_flashloader_amebad.bin` | `0x082000` (RAM) | 4,688 B | System Flashloader, Required |
| 2 | `km0_boot_all.bin` | `0x08000000` | 4,500 B | km0 boot image |
| 3 | `km4_boot_all.bin` | `0x08004000` | 4,456 B | km4 boot image |
| 4 | `km0_km4_image2-4.bin` | `0x08006000` | 1,425,408 B | Application firmware. Select this `-4` file in the flasher (the tutorial screenshot names it `km0_km4_image2.bin` — use the filename in this package) |

See `SHA256SUMS.txt` in this package and verify before flashing.

### Flashing steps (see tutorial image)

1. Connect the BW16 to your computer with a Type-C data cable and check the CH340 serial port appears.
2. Open the web flasher above and select `1500000 (Turbo)` baud (as in the tutorial; lower it and retry if unstable).
3. Under **1. System Flashloader (RAM)**, select `imgtool_flashloader_amebad.bin`, keeping address `0x082000`.
4. Under **2. Firmware Images**, add three rows matching the table above exactly.
5. Put the board into download mode (hold Burn, tap RST, then release Burn — follow your board's silkscreen).
6. Click **START FLASHING** and wait for the log to show completion / Success 100% before unplugging. Do not click ERASE CHIP unless you intentionally want a full chip erase.
7. Power-cycle, join the board's WiFi hotspot, open `8.8.8.8`, and change the default WiFi name and password right away.

### Donations (voluntary, any amount)

If this package helps you, donations are welcome — any amount, entirely voluntary:

- **EVM (ETH / BNB):** `0x0c230520e1419b1ccd2e54db80d15ae70edada9d`
- **Solana:** `7j2EcTBB7haUZtmKj27JDBLTWJ4tpfwj8fwWvAfyqwZf`
